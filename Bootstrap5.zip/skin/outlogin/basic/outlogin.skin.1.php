<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
?>
<li class="nav-item">
	<a class="nav-link" href="<?php echo G5_BBS_URL ?>/login.php">로그인</a>
</li>
