Theme Name: Bootstrap5
Theme URI: https://theme.kilho.net
Maker: KILHO.NET
Maker URI: https://kilho.net
Version: 20230504
Detail: 부트스트랩(5.3)을 그누보드에서 사용할 수 있도록 한 테마입니다.
License: MIT License
License URI: https://opensource.org/licenses/MIT